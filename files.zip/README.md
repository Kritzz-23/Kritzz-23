<h1 align="center">Hi, I'm Kritika Giri 👋</h1>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com/?font=Fira+Code&size=22&pause=1000&color=6C4CF1&center=true&vCenter=true&width=600&lines=Aspiring+AI+Engineer;3rd-Year+AIML+Undergraduate;Applied+ML+%26+NLP+Enthusiast" alt="Typing SVG" />
</p>

<p align="center">
  <a href="https://www.linkedin.com/in/kritika-giri-2320aa345/"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white"></a>
  <a href="mailto:girikritika30@gmail.com"><img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white"></a>
  <a href="https://kritzz-23.github.io/"><img src="https://img.shields.io/badge/Portfolio-16181D?style=for-the-badge&logo=vercel&logoColor=white"></a>
</p>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/Kritzz-23/Kritzz-23/output/github-contribution-grid-snake-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Kritzz-23/Kritzz-23/output/github-contribution-grid-snake.svg">
    <img alt="github contribution grid snake animation" src="https://raw.githubusercontent.com/Kritzz-23/Kritzz-23/output/github-contribution-grid-snake.svg">
  </picture>
</p>

<p align="center">
  🎓 <a href="#education">Education</a> •
  🚀 <a href="#projects">Projects</a> •
  🛠️ <a href="#technologies--tools">Technologies</a> •
  📊 <a href="#github-stats">GitHub Stats</a> •
  📫 <a href="#contact">Contact</a>
</p>

---

## 👋 Introduction

Hi, I'm **Kritika Giri**, a B.Tech Computer Science & Engineering (AI & ML) student passionate about building **applied machine learning** solutions.

I work mainly with **Python**, building **NLP systems**, **ML pipelines**, and data-driven products — from a contract risk analyzer that flags risky legal clauses to a platform that helps students track internships.

I enjoy turning research ideas into working products, and I'm continuously sharpening my skills in ML, NLP, and backend development.

---

## 🎓 Education

**Bachelor of Technology — Computer Science & Engineering (AI & ML)**
Brainware University
**CGPA:** 8.54 (till current semester)
**Expected Graduation:** 2027

---

## 🚀 Projects

<p align="center">
  <a href="https://github.com/Kritzz-23/ai-contract-risk-analyzer">
    <img src="https://github-readme-stats.vercel.app/api/pin/?username=Kritzz-23&repo=ai-contract-risk-analyzer&theme=tokyonight" />
  </a>
  <a href="https://github.com/Kritzz-23/InternIntel-AI">
    <img src="https://github-readme-stats.vercel.app/api/pin/?username=Kritzz-23&repo=InternIntel-AI&theme=tokyonight" />
  </a>
</p>
<p align="center">
  <a href="https://github.com/Kritzz-23/SentinelAI">
    <img src="https://github-readme-stats.vercel.app/api/pin/?username=Kritzz-23&repo=SentinelAI&theme=tokyonight" />
  </a>
  <a href="https://github.com/Kritzz-23/expense-tracker">
    <img src="https://github-readme-stats.vercel.app/api/pin/?username=Kritzz-23&repo=expense-tracker&theme=tokyonight" />
  </a>
</p>

- 🔍 **AI Contract Risk Analyzer** — NLP-based tool that flags risky clauses in legal contracts
- 🎯 **InternIntel AI** — AI-driven platform to discover, manage and track internship opportunities
- 🛡️ **SentinelAI** — Incident intelligence platform that analyzes logs for faster troubleshooting
- 💰 **Smart Expense Tracker** — Responsive web app for tracking and categorizing expenses

---

## 🛠️ Technologies & Tools

**Languages**
<p>
  <img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white">
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black">
  <img src="https://img.shields.io/badge/SQL-4479A1?style=for-the-badge&logo=postgresql&logoColor=white">
</p>

**AI & ML**
<p>
  <img src="https://img.shields.io/badge/Machine%20Learning-6C4CF1?style=for-the-badge">
  <img src="https://img.shields.io/badge/NLP-FF7A00?style=for-the-badge">
  <img src="https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white">
  <img src="https://img.shields.io/badge/NumPy-013243?style=for-the-badge&logo=numpy&logoColor=white">
  <img src="https://img.shields.io/badge/scikit--learn-F7931E?style=for-the-badge&logo=scikitlearn&logoColor=white">
</p>

**Tools**
<p>
  <img src="https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white">
  <img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white">
  <img src="https://img.shields.io/badge/VS%20Code-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=white">
  <img src="https://img.shields.io/badge/Jupyter-F37626?style=for-the-badge&logo=jupyter&logoColor=white">
</p>

---

## 📊 GitHub Stats

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=Kritzz-23&show_icons=true&theme=tokyonight&count_private=true" height="165">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Kritzz-23&layout=compact&theme=tokyonight" height="165">
</p>
<p align="center">
  <img src="https://github-readme-streak-stats.herokuapp.com/?user=Kritzz-23&theme=tokyonight" height="165">
</p>
<p align="center">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=Kritzz-23&theme=react-dark" width="90%">
</p>

---

## 🎯 Current Focus

- 🤖 Applied machine learning & NLP projects
- 📊 Data analysis and model evaluation
- 🧠 Deepening backend + ML integration skills
- 🌱 Continuously building real-world AI products

---

## 📫 Contact

<p align="center">
  <a href="mailto:girikritika30@gmail.com"><img src="https://img.shields.io/badge/Email-girikritika30%40gmail.com-D14836?style=for-the-badge&logo=gmail&logoColor=white"></a>
  <a href="https://www.linkedin.com/in/kritika-giri-2320aa345/"><img src="https://img.shields.io/badge/LinkedIn-Connect-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white"></a>
  <a href="https://github.com/Kritzz-23"><img src="https://img.shields.io/badge/GitHub-Kritzz--23-181717?style=for-the-badge&logo=github&logoColor=white"></a>
</p>
